/**
 * Slate state: thread/episode records, session-scoped persistence.
 *
 * Persistence model (ExecPlan D9): every mutation appends a full snapshot as a
 * custom session entry ("slate-state") via pi.appendEntry. On session_start the
 * store rebuilds from the last current-format entry on the current branch.
 * State follows pi's session tree across restart, resume, and fork.
 */

import { realpathSync, statSync } from "node:fs";
import { isAbsolute, join, relative, sep } from "node:path";
import { CONFIG_DIR_NAME, type ExtensionAPI, type ExtensionContext } from "@earendil-works/pi-coding-agent";
import { isLogicalModelName, type LogicalModelEffort } from "./logical-model-definitions.ts";
/** Compatibility name for Pi's complete thinking-level vocabulary. */
export type ThinkingLevel = LogicalModelEffort;
import type { ObservationRecord } from "./observations.ts";
// TYPE-ONLY, like the effort vocabulary above: the request-throttle module owns
// its own config shape and sanitizer, and this import is erased at load time.
import type { RequestThrottleConfig, SanitizedRequestThrottle } from "./request-throttle.ts";
import { sanitizeForNotify } from "./notify.ts";
import { isSafeThreadId, isSlateArtifactReference, slateEpisodeId } from "./artifact-names.ts";
import { createWritingReminderRuntime, type WritingReminderRuntime } from "./writing-reminder.ts";

/**
 * Snapshot records are unversioned. Older snapshots may contain fields this
 * version no longer uses. Adoption keeps every recognised current field and
 * ignores obsolete router-base fields without dropping the record.
 */
export const THREAD_TYPES = ["researcher", "reviewer", "adversarial", "implementer", "general"] as const;
export type ThreadType = (typeof THREAD_TYPES)[number];

/** Pi's complete thinking-level vocabulary, shared by dispatch and snapshot validation. */
export const THINKING_LEVELS: readonly ThinkingLevel[] = ["off", "minimal", "low", "medium", "high", "xhigh", "max"];

export function isThinkingLevel(value: unknown): value is ThinkingLevel {
	return typeof value === "string" && THINKING_LEVELS.includes(value as ThinkingLevel);
}

/** Intent-only labels for explaining the closed thread-type vocabulary. */
export const THREAD_TYPE_GLOSSES = {
	researcher: "investigates",
	reviewer: "judges work",
	adversarial: "seeks counterexamples",
	implementer: "makes the change",
	general: "is anything else",
} as const satisfies Record<ThreadType, string>;

export function isThreadType(value: unknown): value is ThreadType {
	return typeof value === "string" && (THREAD_TYPES as readonly string[]).includes(value);
}

/** Return the generated ordinal only for the exact canonical thread-id grammar. */
function canonicalThreadOrdinal(value: unknown): number | undefined {
	if (typeof value !== "string") return undefined;
	const match = /^t([1-9]\d*)$/.exec(value);
	if (match === null) return undefined;
	const ordinal = Number(match[1]);
	return Number.isSafeInteger(ordinal) && ordinal >= 1 && value === `t${ordinal}` ? ordinal : undefined;
}

/** Generated thread ids are exactly t followed by one canonical positive safe integer. */
export function isCanonicalThreadId(value: unknown): value is string {
	return canonicalThreadOrdinal(value) !== undefined;
}

/** Render a primary thread id without allowing legacy punctuation to forge surrounding structure. */
export function renderThreadId(value: unknown): string | undefined {
	if (!isSafeThreadId(value)) return undefined;
	return isCanonicalThreadId(value) ? value : JSON.stringify(value);
}

/** Validate the conditionally required tool argument at its runtime boundary. */
export function parseThreadType(value: unknown, required: boolean): ThreadType | undefined {
	const allowed = THREAD_TYPES.join(", ");
	if (value === undefined) {
		if (required) throw new Error(`A type is required when creating a thread. Allowed values: ${allowed}.`);
		return undefined;
	}
	if (!isThreadType(value)) throw new Error(`Invalid thread type. Allowed values: ${allowed}.`);
	return value;
}

function resolveThreadType(value: unknown): ThreadType {
	return isThreadType(value) ? value : "general";
}

/** Resolve a display value without consuming the once-only warning for an adopted record. */
export function displayThreadType(value: unknown): ThreadType {
	return resolveThreadType(value);
}

const reportedUnknownThreadTypes = new WeakSet<ThreadRecord>();

/**
 * Resolve the persisted value at the point where thread behaviour needs it.
 * Old records remain absent. An unknown string also behaves as `general`, but
 * produces one visible report for that adopted record rather than one per use.
 */
export function effectiveThreadType(thread: ThreadRecord, report: (message: string) => void): ThreadType {
	const storedType = thread.type;
	const type = resolveThreadType(storedType);
	if (storedType !== undefined && !isThreadType(storedType) && !reportedUnknownThreadTypes.has(thread)) {
		reportedUnknownThreadTypes.add(thread);
		report(`slate: thread ${thread.id} has unrecognised type ${sanitizeForNotify(storedType, 80)}. Slate is treating it as general.`);
	}
	return type;
}

/** Compact display marker shared by every thread surface; includes its own separator. */
export function threadTypeMarker(type: ThreadType): string {
	return type === "general" ? "" : ` type=${type}`;
}

export interface ThreadRecord {
	id: string; // "t1", "t2", ...
	name: string;
	status: "queued" | "running" | "successful" | "failed" | "cancelled";
	/** Immutable thread type. */
	type: ThreadType;
	/**
	 * PRE-ROUTER pin: "provider/id" passed as `model` when the thread was created
	 * WITH THE ROUTER OFF. It names what a NEW worker session opens on and never
	 * instructs a live one to switch. With the router ON a `model` argument routes
	 * ONE action. It is retained only for compatibility with older snapshots.
	 */
	model?: string;
	/** Effective built-in worker tool allowlist. Absent means an older thread whose tools are unknown. */
	tools?: string[];
	/** The action's only episode. Absent only before work starts or after an unbilled abort. */
	episodeId?: string;
	/** Failure or cancellation reason. */
	outcomeReason?: string;
	createdAt: number;
	updatedAt: number;
}

export interface EpisodeUsage {
	input?: number;
	output?: number;
	cacheRead?: number;
	cacheWrite?: number;
}

export interface EpisodeRecord {
	id: string; // "t1.e2"
	threadId: string;
	task: string;
	status: "ok" | "failed";
	file: string; // absolute path to episode .md
	/** Sanitized caller rationale. Absent on episodes written before explicit dispatch metadata. */
	reason?: string;
	/** Provider-free logical action selection. Absent on episodes written before logical routing. */
	logicalModel?: string;
	/** The model requested for this action, before failover. */
	requestedModel?: string;
	/** The effort requested for this action, before failover or provider clamping. */
	requestedEffort?: ThinkingLevel;
	/** Latest physical pair accepted for local Pi handoff. Absent = no accepted request. */
	model?: string;
	/** Post-clamp effort in the latest accepted local Pi handoff. Absent = none accepted. */
	effort?: ThinkingLevel;
	/** Set only when that effort level has NO capability measurement in the profile data. */
	effortUnmeasured?: true;
	/** Exact final-message capture facts. Absent on episodes written before this field existed. */
	observations?: ObservationRecord;
	/** Worker input tokens. Absent means the provider did not report this quantity. */
	input?: number;
	/** Worker output tokens. Absent means the provider did not report this quantity. */
	output?: number;
	/** Worker prompt-cache read tokens. Absent means the provider did not report this quantity. */
	cacheRead?: number;
	/** Worker prompt-cache write tokens. Absent means the provider did not report this quantity. */
	cacheWrite?: number;
	/** Final reported worker context tokens. Absent means the provider did not report a finite count. */
	contextTokens?: number;
	/** Reported worker-call cost in USD. Absent means no worker call reported cost. */
	workerCostUsd?: number;
	/** Usage billed by episode compression. Each absent quantity was not reported. */
	compressorUsage?: EpisodeUsage;
	/** Reported compression-call cost in USD. Absent means no compression call reported cost. */
	compressorCostUsd?: number;
	/** Usage billed by platform context compaction during this dispatch. */
	compactionUsage?: EpisodeUsage;
	/** Reported compaction-call cost in USD. Absent means no compaction call reported cost. */
	compactionCostUsd?: number;
	createdAt: number;
}

export const SLATE_STATE_FORMAT = "single-action-v1";

export interface SlateSnapshot {
	format: typeof SLATE_STATE_FORMAT;
	threads: ThreadRecord[];
	episodes: EpisodeRecord[];
	/** Highest allocated generated thread ordinal. Absent snapshots derive it from records. */
	threadSeq?: number;
	orchestratorMode: boolean;
	paused: boolean;
	workerCostUsd: number;
	carriedCostUsd: number; // orchestrator spend banked from ancestor sessions at handoff
}

/**
 * Canonical "provider/id" model-spec parsing — the ONE definition (CQ2).
 *
 * The pattern (validate, then split on the FIRST slash) had grown four
 * near-identical copies: failover.ts's local `isModelSpec`, and the inline
 * `indexOf("/")` splits in episodes.ts, worker.ts and the model router. All four
 * now call these helpers. It lives here because state.ts is where the config
 * vocabulary that uses it is defined (`episodeModel`, `modelFailover`,
 * `router.models`, the contextBudget override `match`), and because state.ts
 * imports nothing from those modules, so no call site can create an import cycle
 * by adopting it.
 *
 * ONE definition matters more than the duplication it removes: while failover.ts
 * kept its own laxer copy, two live predicates DISAGREED about the same config
 * string — the router rejected a spec with an embedded newline that failover
 * happily stored in its map and then failed to resolve, silently.
 *
 * The FIRST slash splits, deliberately: proxy providers legitimately carry a
 * slash inside the model id ("openrouter/anthropic/claude-..."), so provider is
 * everything before the first slash and id is all the rest.
 *
 * Whitespace, control characters and every ZERO-WIDTH or DIRECTION-CHANGING
 * character are REJECTED rather than trimmed (BG2). Such a spec resolves nowhere
 * in pi's registry, yet renders in a warning as a byte-identical twin of the
 * valid name once the display sanitizer strips the offending character — a
 * zero-width space, a variation selector or a right-to-left override is worse
 * still, since it survives sanitization and displays as nothing at all.
 * Rejecting them lets the caller say what is actually wrong
 * (describeSpecDefect). What is left after that is the VISIBLE confusable case —
 * a homoglyph such as Cyrillic "а" for Latin "a" — which cannot be rejected,
 * because an exotic provider id may be genuinely non-ASCII, so it is ANNOTATED
 * at display time instead (describeConfusables).
 */

/**
 * Characters that are never part of a real model spec because they occupy no
 * visible width, or change the direction of what follows.
 *
 * The two Unicode categories carry most of it — `Cc` (C0/C1 controls) and `Cf`
 * (format: soft hyphen, Arabic letter mark, Mongolian vowel separator,
 * zero-width space/joiners, LRM/RLM, the bidi embedding/override/isolate
 * controls, word joiner and invisible operators, interlinear annotation marks,
 * the tag characters, and the BOM) — plus `Cs` (a lone surrogate is broken text,
 * never an identifier).
 *
 * Three invisible classes are NOT in those categories and must be listed
 * explicitly (the residual BG2 finding): VARIATION SELECTORS (`Mn`: U+FE00–FE0F
 * and U+E0100–E01EF) and HANGUL FILLERS (`Lo`, and therefore "letters" as far as
 * any category test is concerned: U+115F, U+1160, U+3164, U+FFA0). Unicode
 * property escapes need the `u` flag; every use below tests one code point at a
 * time, which is why `codePointList` iterates with for…of rather than by index.
 */
const INVISIBLE_SPEC_CHARS = /[\p{Cc}\p{Cf}\p{Cs}\u115f\u1160\u3164\ufe00-\ufe0f\uffa0]|[\u{e0100}-\u{e01ef}]/u;

/** "U+XXXX" list of the first few characters of `value` that match `pattern`, de-duplicated. */
function codePointList(value: string, pattern: RegExp, max = 3): string {
	const seen: string[] = [];
	for (const ch of value) {
		if (!pattern.test(ch)) continue;
		const point = `U+${(ch.codePointAt(0) ?? 0).toString(16).toUpperCase().padStart(4, "0")}`;
		if (!seen.includes(point)) seen.push(point);
		if (seen.length > max) return `${seen.slice(0, max).join(", ")}, …`;
	}
	return seen.join(", ");
}

export function isModelSpec(value: unknown): value is string {
	if (typeof value !== "string") return false;
	if (/\s/.test(value) || INVISIBLE_SPEC_CHARS.test(value)) return false;
	const slash = value.indexOf("/");
	return slash > 0 && slash < value.length - 1;
}

/** Split a validated spec into provider + id (first slash wins); undefined when it is not a spec. */
export function splitModelSpec(value: unknown): { provider: string; id: string } | undefined {
	if (!isModelSpec(value)) return undefined;
	const slash = value.indexOf("/");
	return { provider: value.slice(0, slash), id: value.slice(slash + 1) };
}

const REASON_LINE_SEPARATORS = /[\p{Zl}\p{Zp}]/gu;
const REASON_INVISIBLE_CHARS = /[\p{Cc}\p{Cf}\p{Cs}\u115f\u1160\u3164\ufe00-\ufe0f\uffa0]|[\u{e0100}-\u{e01ef}]/gu;

/** Sanitize explicit-dispatch metadata without changing unrelated notification text. */
export function sanitizeDispatchReason(value: unknown): string | undefined {
	if (typeof value !== "string") return undefined;
	const clean = value.replace(REASON_LINE_SEPARATORS, " ").replace(REASON_INVISIBLE_CHARS, "").trim();
	return clean !== "" && clean.length <= 200 ? clean : undefined;
}

/**
 * Why `value` is not a canonical spec, as a clause that survives display
 * sanitization (BG2). The RENDERING of an invisible or padded spec is identical
 * to a valid name, so the reason has to carry the information — and for the
 * invisible classes it names the offending code points, which are plain ASCII.
 */
export function describeSpecDefect(value: unknown): string {
	if (typeof value !== "string") return `expected a string, got ${typeof value}`;
	if (value === "") return "it is empty";
	if (INVISIBLE_SPEC_CHARS.test(value)) {
		return `it contains invisible or control characters (${codePointList(value, INVISIBLE_SPEC_CHARS)}) — they display as nothing, so this is not the name it looks like`;
	}
	if (/^\s|\s$/.test(value)) return "it has leading or trailing whitespace (invisible here, but pi's registry has no such model)";
	if (/\s/.test(value)) return "it contains whitespace";
	if (!value.includes("/")) return 'it has no "/" separating provider from model id';
	if (value.startsWith("/")) return 'it has an empty provider before the "/"';
	if (value.endsWith("/")) return 'it has an empty model id after the "/"';
	return "it is not of the form provider/id";
}

/**
 * Display-time note for a spec that PASSES validation but contains non-ASCII
 * characters (BG2's remaining case: VISIBLE confusables, not invisible ones —
 * those are rejected outright above). A Cyrillic "а" in an otherwise valid spec
 * renders exactly like the Latin one, so a warning about it would otherwise look
 * like a warning about the model the user meant. The note is deliberately about
 * non-ASCII in general rather than a curated homoglyph table: any non-ASCII
 * character in a spec is worth pointing at, and enumerating confusables is a
 * losing game. Returns undefined for a pure printable-ASCII spec, the normal case.
 */
export function describeConfusables(value: string): string | undefined {
	// Printable-ASCII complement. Neither this nor INVISIBLE_SPEC_CHARS carries the
	// /g flag, because codePointList calls .test() per character and a sticky/global
	// regex would keep lastIndex between those calls and skip matches.
	const nonAscii = /[^\u0020-\u007e]/;
	if (!nonAscii.test(value)) return undefined;
	return `contains non-ASCII characters: ${codePointList(value, nonAscii)}`;
}


/** Validate the explicit prompt-cache-key feature switch. */
export function sanitizeCacheKeyEnabled(raw: unknown, warn: (msg: string) => void): boolean {
	if (raw === undefined) return true;
	if (typeof raw === "boolean") return raw;
	warn(`slate: ignoring cacheKeyEnabled ${sanitizeForNotify(String(raw))} — expected a boolean. Using true.`);
	return true;
}

/**
 * Report the REMOVED cache-key partitioning setting and ignore it.
 *
 * Slate no longer partitions the prompt cache key. One key belongs to the whole
 * main session, so a shard count can no longer mean anything. The key stays
 * accepted in a config file, reports itself once per session load, and changes
 * nothing.
 */
export function warnRemovedCacheKeyShards(raw: unknown, warn: (msg: string) => void): void {
	if (raw === undefined) return;
	warn(
		`slate: cacheKeyShards ${sanitizeForNotify(String(raw))} is a removed setting and has no effect. Remove it from slate.json. Slate uses one prompt cache key for each main session.`,
	);
}

/**
 * ADOPTION-BOUNDARY VALIDATION (BG26). A snapshot is JSON on disk: unversioned,
 * hand-editable, and written by whatever slate version wrote it. The record types
 * above describe what slate WRITES; they guarantee nothing about what it reads back,
 * and until this existed a single wrong-typed field crashed a dispatch rather than
 * degrading — a non-string `baseModel` reached a warning builder as
 * `s.replace is not a function`, and the exception escaped out of the `thread` tool.
 * A non-numeric `updatedAt` had the same shape one layer up (`new Date(x).toISOString()`
 * throws on NaN, in the threads listing).
 *
 * The rule is the one BG21 established for the stored effort level, applied to every
 * field: a value of the wrong TYPE reads as absent (or, where the record cannot exist
 * without it, drops the record), and the caller is told. Deliberately a TYPE check and
 * not a content check for the model fields: a padded or otherwise malformed spec is
 * still handed to pi, whose own error names the defect (CQ13/RG1) — repairing it here
 * would hide it, and dropping it would change what a restarted thread runs on.
 */
function str(value: unknown): string | undefined {
	return typeof value === "string" ? value : undefined;
}
function stringList(value: unknown): string[] | undefined {
	return Array.isArray(value) && value.every((item) => typeof item === "string") ? [...value] : undefined;
}
function num(value: unknown): number | undefined {
	return typeof value === "number" && Number.isFinite(value) ? value : undefined;
}
function counter(value: unknown): number | undefined {
	return typeof value === "number" && Number.isSafeInteger(value) && value >= 0 ? value : undefined;
}
function tokenQuantity(value: unknown): number | undefined {
	return typeof value === "number" && Number.isFinite(value) && Number.isInteger(value) && value >= 0 ? value : undefined;
}
function moneyAmount(value: unknown): number | undefined {
	return typeof value === "number" && Number.isFinite(value) && value >= 0 ? value : undefined;
}

/** Resolve a regular episode file only when its real path stays inside slate's episode directory. */
export function resolveEpisodeFile(cwd: string, value: unknown): string | undefined {
	if (typeof value !== "string" || value === "") return undefined;
	try {
		const expectedRoot = join(realpathSync(cwd), CONFIG_DIR_NAME, "slate", "episodes");
		const root = realpathSync(expectedRoot);
		if (root !== expectedRoot || !statSync(root).isDirectory()) return undefined;
		const file = realpathSync(value);
		if (!statSync(file).isFile()) return undefined;
		const inside = relative(root, file);
		if (inside === "" || inside === ".." || inside.startsWith(`..${sep}`) || isAbsolute(inside)) {
			return undefined;
		}
		return file;
	} catch {
		return undefined;
	}
}

/** Validate the complete observation record, including its exact canonical reference. */
function observationRecord(value: unknown, episodeId: string): ObservationRecord | undefined {
	// Keep this as a strict tagged union. Extra keys and array-shaped objects are rejected.
	if (typeof value !== "object" || value === null || Array.isArray(value)) return undefined;
	const o = value as Record<string, unknown>;
	const exactKeys = (expected: string[]) => {
		const keys = Object.keys(o);
		return keys.length === expected.length && keys.every((key) => expected.includes(key));
	};
	const grammar = o.grammar === "present" || o.grammar === "absent" || o.grammar === "malformed" ? o.grammar : undefined;
	if (o.stored === true) {
		const path = isSlateArtifactReference(o.path, "observations", episodeId) ? o.path : undefined;
		const bytes = typeof o.bytes === "number" && Number.isSafeInteger(o.bytes) && o.bytes >= 0 ? o.bytes : undefined;
		if (!exactKeys(["stored", "path", "bytes", "truncated", "grammar"]) || path === undefined || bytes === undefined || typeof o.truncated !== "boolean" || grammar === undefined) return undefined;
		return { stored: true, path, bytes, truncated: o.truncated, grammar };
	}
	if (o.stored === false) {
		if (!exactKeys(["stored", "reason", "grammar"]) || grammar === undefined) return undefined;
		if ((o.reason === "no-final-message" || o.reason === "no-final-text") && grammar === "absent") {
			return { stored: false, reason: o.reason, grammar };
		}
		if (o.reason === "write-failed") return { stored: false, reason: o.reason, grammar };
	}
	return undefined;
}

/**
 * EXHAUSTIVENESS WITNESSES for the two sanitizers below (CQ22).
 *
 * Adoption is an ALLOWLIST: a field the sanitizer does not name is dropped on restore.
 * That is the right default for hostile input, but it means adding an optional field to
 * ThreadRecord or EpisodeRecord and forgetting the sanitizer costs the field silently on
 * every session restart — no crash, no warning, and a required field would be caught by
 * the return type while an optional one would not.
 *
 * These maps close that: `satisfies Record<keyof Required<T>, true>` fails to compile
 * both ways — a MISSING key (the new field nobody adopted) and an EXTRA one (a field
 * that was removed from the record). The value is deliberately `true` and nothing more;
 * the map is a checklist for the compiler, not a schema, and each sanitizer must still
 * decide what its fields mean. Keep the keys in record order so the diff reads as a
 * checklist too.
 *
 * EXPORTED so a checker can walk them: hand a sanitizer a record with every field valid
 * and every key here must come back, which is the same claim from the outside and needs
 * no type checker at all.
 */
export const ADOPTED_THREAD_FIELDS = {
	id: true,
	name: true,
	status: true,
	type: true,
	model: true,
	tools: true,
	episodeId: true,
	outcomeReason: true,
	createdAt: true,
	updatedAt: true,
} satisfies Record<keyof Required<ThreadRecord>, true>;

export const ADOPTED_EPISODE_FIELDS = {
	id: true,
	threadId: true,
	task: true,
	status: true,
	file: true,
	reason: true,
	logicalModel: true,
	requestedModel: true,
	requestedEffort: true,
	model: true,
	effort: true,
	effortUnmeasured: true,
	observations: true,
	input: true,
	output: true,
	cacheRead: true,
	cacheWrite: true,
	contextTokens: true,
	workerCostUsd: true,
	compressorUsage: true,
	compressorCostUsd: true,
	compactionUsage: true,
	compactionCostUsd: true,
	createdAt: true,
} satisfies Record<keyof Required<EpisodeRecord>, true>;

/**
 * The RUNTIME half, and the reason the witnesses are values and not pure types: this
 * repo has no compile step (pi loads TypeScript through jiti, which strips types without
 * checking them), so a `satisfies` failure is a red squiggle in an editor and nothing
 * more. Worse, the obvious way to silence that squiggle — adding the key to the map —
 * fixes the checklist without teaching the sanitizer anything, and the field is dropped
 * as silently as before.
 *
 * So the checklist is also enforced against what the sanitizer actually BUILT: a field
 * the snapshot carries, that adoption claims to know, that the built record lacks, and
 * that was not deliberately refused (those are already reported by name) is a slate bug,
 * and it says so. Cheap — one pass over ten keys per record — and it fires on the first
 * restore after the omission rather than whenever the missing data is next needed.
 *
 * Exported for the same reason as the checklists: a checker can drive it with a record
 * that is deliberately missing a handled field, which is the one situation this codebase
 * cannot produce on purpose.
 */
export function noteUnadoptedFields(
	kind: "thread" | "episode",
	id: string,
	raw: Record<string, unknown>,
	built: object,
	refused: Set<string>,
	repairs: string[],
): void {
	const known = Object.keys(kind === "thread" ? ADOPTED_THREAD_FIELDS : ADOPTED_EPISODE_FIELDS);
	const adopted = new Set(Object.keys(built));
	for (const field of known) {
		if (raw[field] === undefined || adopted.has(field) || refused.has(field)) continue;
		repairs.push(`${kind} ${id}: field ${field} is in the snapshot but adoption does not handle it (slate bug) — its value is lost`);
	}
	// Deliberately NOT reported: a key this version knows nothing about. That is a
	// snapshot from a different slate version, nothing of this version's is at risk, and
	// on a downgrade the notice would fire for every field of every record.
}

/**
 * One adopted thread record, or undefined when it cannot be addressed at all (no id).
 * `repairs` collects a human-readable note per dropped field so a corrupted snapshot is
 * VISIBLE rather than silently reshaped.
 */
export function sanitizeThreadRecord(raw: unknown, repairs: string[]): ThreadRecord | undefined {
	if (typeof raw !== "object" || raw === null) return undefined;
	const t = raw as Record<string, unknown>;
	const id = str(t.id);
	if (id === undefined || !isCanonicalThreadId(id)) {
		repairs.push("thread record: invalid id");
		return undefined;
	}
	const name = str(t.name);
	const type = isThreadType(t.type) ? t.type : undefined;
	const status = typeof t.status === "string" && (["queued", "running", "successful", "failed", "cancelled"] as const).includes(t.status as ThreadRecord["status"])
		? t.status as ThreadRecord["status"]
		: undefined;
	if (name === undefined || type === undefined || status === undefined) {
		const field = name === undefined ? "name" : type === undefined ? "type" : "status";
		repairs.push(`thread ${id}: invalid ${field}`);
		return undefined;
	}
	const refused = new Set<string>();
	const keep = <T>(field: string, value: unknown, parsed: T | undefined): T | undefined => {
		if (value !== undefined && parsed === undefined) {
			refused.add(field);
			repairs.push(`thread ${id}: ignoring ${field} (${typeof value === "object" ? "object" : typeof value})`);
		}
		return parsed;
	};
	const tools = keep("tools", t.tools, stringList(t.tools));
	const parsedEpisodeId = keep("episodeId", t.episodeId, str(t.episodeId));
	const episodeId = parsedEpisodeId === undefined || parsedEpisodeId === slateEpisodeId(id) ? parsedEpisodeId : undefined;
	if (parsedEpisodeId !== undefined && episodeId === undefined) {
		refused.add("episodeId");
		repairs.push(`thread ${id}: ignoring episodeId because it is not ${id}.e1`);
	}
	let outcomeReason = keep("outcomeReason", t.outcomeReason, str(t.outcomeReason));
	let adoptedStatus = status;
	if (status === "running" || status === "queued") {
		adoptedStatus = "failed";
		outcomeReason = "the session ended before the action finished";
		repairs.push(`thread ${id}: normalized unfinished ${status} action to failed`);
	} else if (status === "successful" && episodeId === undefined) {
		adoptedStatus = "failed";
		outcomeReason = "the stored successful action has no valid episode id";
		repairs.push(`thread ${id}: normalized successful action without a valid episode id to failed`);
	}
	const now = Date.now();
	const built: ThreadRecord = {
		id,
		name,
		status: adoptedStatus,
		type,
		model: keep("model", t.model, str(t.model)),
		// A `cacheKeyShard` from an older snapshot is NOT named here on purpose. It is
		// obsolete routing metadata, so adoption drops it in silence while every other
		// field of that thread — its history, its status and its episode — is kept.
		tools,
		episodeId,
		outcomeReason,
		createdAt: keep("createdAt", t.createdAt, num(t.createdAt)) ?? now,
		updatedAt: keep("updatedAt", t.updatedAt, num(t.updatedAt)) ?? now,
	};
	noteUnadoptedFields("thread", id, t, built, refused, repairs);
	return built;
}

/**
 * One adopted episode record, or undefined when it cannot be addressed or filed. Same
 * discipline as the thread record above: a wrong-typed field is refused BY NAME (so the
 * repair is visible, and so the CQ22 coverage check can tell a deliberate refusal from
 * an unhandled field), and the record type's own checklist is enforced at the end.
 */
export function sanitizeEpisodeRecord(raw: unknown, repairs: string[]): EpisodeRecord | undefined {
	if (typeof raw !== "object" || raw === null) return undefined;
	const e = raw as Record<string, unknown>;
	const id = str(e.id);
	const threadId = str(e.threadId);
	const file = str(e.file);
	if (id === undefined || id === "" || threadId === undefined || file === undefined) return undefined;
	if (!isCanonicalThreadId(threadId) || id !== slateEpisodeId(threadId)) {
		repairs.push(`episode ${id || "record"}: id must be the thread's canonical .e1 id`);
		return undefined;
	}
	const refused = new Set<string>();
	const keep = <T>(field: string, value: unknown, parsed: T | undefined): T | undefined => {
		if (value !== undefined && parsed === undefined) {
			refused.add(field);
			repairs.push(`episode ${id}: ignoring ${field} (${typeof value === "object" ? "object" : typeof value})`);
		}
		return parsed;
	};
	const observations = keep("observations", e.observations, observationRecord(e.observations, id));
	const nestedUsage = (name: "compressorUsage" | "compactionUsage", value: unknown): EpisodeUsage | undefined => {
		if (typeof value !== "object" || value === null || Array.isArray(value)) return undefined;
		const raw = value as Record<string, unknown>;
		const usage: EpisodeUsage = {};
		for (const field of ["input", "output", "cacheRead", "cacheWrite"] as const) {
			const parsed = tokenQuantity(raw[field]);
			if (raw[field] !== undefined && parsed === undefined) {
				repairs.push(`episode ${id}: ignoring ${name}.${field} (${typeof raw[field]})`);
			} else if (parsed !== undefined) {
				usage[field] = parsed;
			}
		}
		return usage;
	};
	const compressorUsage = keep("compressorUsage", e.compressorUsage, nestedUsage("compressorUsage", e.compressorUsage));
	const compactionUsage = keep("compactionUsage", e.compactionUsage, nestedUsage("compactionUsage", e.compactionUsage));
	const reason = keep("reason", e.reason, sanitizeDispatchReason(e.reason));
	const logicalModel = keep("logicalModel", e.logicalModel, isLogicalModelName(e.logicalModel) ? e.logicalModel : undefined);
	const requestedModel = keep("requestedModel", e.requestedModel, isModelSpec(e.requestedModel) ? e.requestedModel : undefined);
	const requestedEffort = keep("requestedEffort", e.requestedEffort, isThinkingLevel(e.requestedEffort) ? e.requestedEffort : undefined);
	const built: EpisodeRecord = {
		id,
		threadId,
		task: keep("task", e.task, str(e.task)) ?? "",
		// A status that is neither of the two words reads as "ok": the record exists, so
		// something ran, and inventing a failure would be worse than ignoring the value.
		status: keep("status", e.status, e.status === "failed" || e.status === "ok" ? e.status : undefined) ?? "ok",
		file,
		...(reason !== undefined ? { reason } : {}),
		...(logicalModel !== undefined ? { logicalModel } : {}),
		...(requestedModel !== undefined ? { requestedModel } : {}),
		...(requestedEffort !== undefined ? { requestedEffort } : {}),
		...(keep("model", e.model, str(e.model)) !== undefined ? { model: str(e.model) } : {}),
		...(keep("effort", e.effort, str(e.effort)) !== undefined ? { effort: str(e.effort) as ThinkingLevel } : {}),
		...(keep("effortUnmeasured", e.effortUnmeasured, e.effortUnmeasured === true ? (true as const) : undefined) !== undefined
			? { effortUnmeasured: true as const }
			: {}),
		...(observations !== undefined ? { observations } : {}),
		...(keep("input", e.input, tokenQuantity(e.input)) !== undefined ? { input: tokenQuantity(e.input) } : {}),
		...(keep("output", e.output, tokenQuantity(e.output)) !== undefined ? { output: tokenQuantity(e.output) } : {}),
		...(keep("cacheRead", e.cacheRead, tokenQuantity(e.cacheRead)) !== undefined ? { cacheRead: tokenQuantity(e.cacheRead) } : {}),
		...(keep("cacheWrite", e.cacheWrite, tokenQuantity(e.cacheWrite)) !== undefined ? { cacheWrite: tokenQuantity(e.cacheWrite) } : {}),
		...(keep("contextTokens", e.contextTokens, tokenQuantity(e.contextTokens)) !== undefined
			? { contextTokens: tokenQuantity(e.contextTokens) }
			: {}),
		...(keep("workerCostUsd", e.workerCostUsd, moneyAmount(e.workerCostUsd)) !== undefined
			? { workerCostUsd: moneyAmount(e.workerCostUsd) }
			: {}),
		...(compressorUsage !== undefined ? { compressorUsage } : {}),
		...(keep("compressorCostUsd", e.compressorCostUsd, moneyAmount(e.compressorCostUsd)) !== undefined
			? { compressorCostUsd: moneyAmount(e.compressorCostUsd) }
			: {}),
		...(compactionUsage !== undefined ? { compactionUsage } : {}),
		...(keep("compactionCostUsd", e.compactionCostUsd, moneyAmount(e.compactionCostUsd)) !== undefined
			? { compactionCostUsd: moneyAmount(e.compactionCostUsd) }
			: {}),
		createdAt: keep("createdAt", e.createdAt, num(e.createdAt)) ?? Date.now(),
	};
	noteUnadoptedFields("episode", id, e, built, refused, repairs); // CQ22
	return built;
}

/** One contextBudget override. `match` is a regex tested ANCHORED (^(?:match)$) against "provider/id". */
export interface ContextBudgetOverride {
	match: string;
	tokens: number;
}

export interface ContextBudgetObject {
	tokens?: number; // absolute token budget for models not caught by an override
	overrides?: ContextBudgetOverride[]; // first matching entry wins
}

/** Trusted logical-model policy configuration. The resolver validates its closed grammar. */
export type LogicalRouterConfig = unknown;

/** Optional raw workflow publishing and completion controls. */
export interface WorkflowConfig {
	draftPRs?: boolean;
	followUpIssues?: boolean;
	routingRecommendations?: boolean;
}

/** Sanitized workflow shape. draftPRs stays unvalidated until issue 164 resolves it. */
export interface SanitizedWorkflowConfig {
	draftPRs?: unknown;
	followUpIssues: boolean;
	routingRecommendations: boolean;
}

/** Display a rejected workflow value without letting serialization abort session startup. */
function quotedWorkflowValue(value: unknown): string {
	let text: string | undefined;
	try {
		text = JSON.stringify(value);
	} catch {
		text = undefined;
	}
	if (text === undefined) {
		try {
			text = String(value);
		} catch {
			text = `[unprintable ${typeof value}]`;
		}
	}
	return sanitizeForNotify(text);
}

/** Validate workflow switches while preserving an own draft publishing value. */
export function sanitizeWorkflowConfig(raw: unknown, warn: (msg: string) => void): SanitizedWorkflowConfig {
	const defaults = { followUpIssues: false, routingRecommendations: false };
	if (raw === undefined) return defaults;
	if (typeof raw !== "object" || raw === null || Array.isArray(raw)) return defaults;
	const value = raw as { draftPRs?: unknown; followUpIssues?: unknown; routingRecommendations?: unknown };
	const hasOwn = (key: "draftPRs" | "followUpIssues" | "routingRecommendations") => Object.prototype.hasOwnProperty.call(value, key);
	const draftPRs = hasOwn("draftPRs") ? { draftPRs: value.draftPRs } : {};
	const booleanValue = (key: "followUpIssues" | "routingRecommendations"): boolean => {
		const candidate = hasOwn(key) ? value[key] : undefined;
		if (candidate === undefined) return false;
		if (typeof candidate === "boolean") return candidate;
		warn(`slate: ignoring workflow.${key} ${quotedWorkflowValue(candidate)}. Expected true or false. Slate uses false.`);
		return false;
	};
	return {
		...draftPRs,
		followUpIssues: booleanValue("followUpIssues"),
		routingRecommendations: booleanValue("routingRecommendations"),
	};
}

/** Writing configuration. Ignored writing keys remain accepted for compatibility. */
export interface WritingConfig {
	check?: boolean;
	remind?: boolean;
	remindPercent?: number;
	remindTurns?: number;
	remindOnFinding?: boolean;
	sentenceWordLimit?: number | false;
	statusWindowTurns?: number;
	findings?: boolean;
}

export interface SlateConfig {
	episodeModel?: unknown; // legacy key, ignored visibly by logical policy resolution
	workerTools?: string[];
	workerExtensions?: string[]; // regex patterns selecting which of the HOST session's pi extensions worker threads may load (default [] = none); see worker-extensions.ts
	cacheKeyEnabled?: boolean; // set false to disable prompt cache keys entirely (default true)
	cacheKeyShards?: number; // REMOVED partitioning setting: accepted, reported once at session load, and ignored
	requestThrottle?: RequestThrottleConfig | SanitizedRequestThrottle; // raw or session-sanitized per-model worker request pacing — see request-throttle.ts
	maxConcurrent?: number; // global cap on concurrently running worker actions (default 4; must be ≥ 1 — unenforced, ≤ 0 silently hangs all dispatches; rationale: docs/design-principles.md §5 repo-local note)
	pauseThresholdPercent?: number; // DEPRECATED: legacy percent-based auto-pause (default 40); applies only when set AND contextBudget is absent or entirely invalid (invalid sanitizes to absent — a partially invalid object stays budget mode)
	contextBudget?: number | ContextBudgetObject; // absolute orchestrator token budget; bare number = { tokens: N }; {} opts into built-in defaults (256k, 400k for anthropic/*) — see handoff.ts
	orchestratorModeDefault?: boolean; // seed orchestrator mode ON for fresh interactive sessions (unsaved until first real mutation)
	orchestratorPromptDocs?: string[]; // role-guideline docs appended to the orchestrator prompt (source-relative paths resolved by config.ts)
	workerPromptDocs?: string[]; // role-guideline docs appended to worker system prompts (source-relative paths resolved by config.ts)
	workflow?: WorkflowConfig | SanitizedWorkflowConfig; // raw or session-sanitized workflow controls (both default false)
	modelFailover?: unknown; // legacy key, ignored visibly by logical policy resolution
	preserveGlobalModelDefault?: boolean; // restore the user's GLOBAL pi model defaults (defaultProvider/defaultModel/defaultThinkingLevel) after a slate-initiated model switch — failover and handoff adoption (default true; only an explicit false disables it) — see model-default.ts
	doctrineExtraPath?: string; // source-relative markdown appended to the orchestrator doctrine
	reviewPerspectivesPath?: string; // source-relative markdown with additional review perspectives
	router?: LogicalRouterConfig; // trusted logical-model policy, validated as one blocking unit
	writing?: WritingConfig; // always-active writing guidance and configurable reminder cadence — see writing.ts
}

export class SlateStore {
	threads = new Map<string, ThreadRecord>();
	episodes = new Map<string, EpisodeRecord>();
	private threadSeq = 0;
	orchestratorMode = false;
	/** When true with orchestratorMode (context budget exceeded), the pi input hook refuses new user prompts. Worker dispatches stay open for the state save. */
	paused = false;
	/**
	 * Cumulative USD spend of worker threads this session. Includes the episode
	 * compressor's LLM calls, so the "workers" figure shown in the widget covers
	 * compression spend too.
	 */
	workerCostUsd = 0;
	/** Orchestrator spend inherited from ancestor sessions across handoffs. */
	carriedCostUsd = 0;
	/** Session-instance reminder state. It is never part of a snapshot. */
	readonly writingReminder: WritingReminderRuntime = createWritingReminderRuntime();
	/** Invoked after every save/restore; used by mode.ts to refresh the widget. */
	onDidChange?: () => void;

	private pi: ExtensionAPI;

	constructor(pi: ExtensionAPI) {
		this.pi = pi;
	}

	nextThreadId(): string {
		let max = this.threadSeq;
		for (const id of this.threads.keys()) {
			const ordinal = canonicalThreadOrdinal(id);
			if (ordinal !== undefined) max = Math.max(max, ordinal);
		}
		return `t${max + 1}`;
	}

	claimNextThreadId(): string {
		const id = this.nextThreadId();
		this.threadSeq = Number(id.slice(1));
		return id;
	}

	snapshot(): SlateSnapshot {
		return {
			format: SLATE_STATE_FORMAT,
			threads: [...this.threads.values()],
			episodes: [...this.episodes.values()],
			threadSeq: this.threadSeq,
			orchestratorMode: this.orchestratorMode,
			paused: this.paused,
			workerCostUsd: this.workerCostUsd,
			carriedCostUsd: this.carriedCostUsd,
		};
	}

	save(): void {
		this.pi.appendEntry("slate-state", this.snapshot() as unknown as Record<string, unknown>);
		this.onDidChange?.();
	}

	/** Rebuild from the last slate-state entry on the current branch. */
	restore(ctx: ExtensionContext): void {
		let latest: SlateSnapshot | undefined;
		for (const entry of ctx.sessionManager.getBranch()) {
			const e = entry as { type: string; customType?: string; data?: unknown };
			if (e.type === "custom" && e.customType === "slate-state" && e.data) {
				latest = e.data as SlateSnapshot;
			}
		}
		this.adoptSnapshot(latest, ctx);
		// Cost counters are NOT branch-scoped like the records above: money never
		// un-spends, and dispatches on now-abandoned branches were still billed.
		// Take the MAX over ALL slate-state entries (both counters are monotonic
		// within a session file) so a branch switch cannot roll them back.
		for (const entry of ctx.sessionManager.getEntries()) {
			const e = entry as {
				type: string;
				customType?: string;
				data?: { format?: unknown; workerCostUsd?: number; carriedCostUsd?: number };
			};
			if (e.type !== "custom" || e.customType !== "slate-state" || e.data?.format !== SLATE_STATE_FORMAT) continue;
			this.workerCostUsd = Math.max(this.workerCostUsd, e.data?.workerCostUsd ?? 0);
			this.carriedCostUsd = Math.max(this.carriedCostUsd, e.data?.carriedCostUsd ?? 0);
		}
	}

	/**
	 * Replace all state with a snapshot (undefined clears), dropping records
	 * whose files vanished. Shared by restore() and the cross-session handoff
	 * adoption in handoff.ts.
	 */
	adoptSnapshot(latest: SlateSnapshot | undefined, ctx: ExtensionContext): void {
		this.threads.clear();
		this.episodes.clear();
		this.threadSeq = 0;
		this.orchestratorMode = false;
		this.paused = false;
		this.workerCostUsd = 0;
		this.carriedCostUsd = 0;
		if (!latest || latest.format !== SLATE_STATE_FORMAT) return;

		this.orchestratorMode = latest.orchestratorMode ?? false;
		this.paused = latest.paused ?? false;
		// ?? 0: old snapshots lack the cost fields.
		this.workerCostUsd = latest.workerCostUsd ?? 0;
		this.carriedCostUsd = latest.carriedCostUsd ?? 0;
		this.threadSeq = counter(latest.threadSeq) ?? 0;
		const dropped: string[] = [];
		// EVERY record is validated field by field on the way in (BG26) — see
		// sanitizeThreadRecord. Nothing downstream re-checks these types, so a snapshot
		// that has been hand-edited, truncated or written by another version must be made
		// safe HERE; the alternative was an exception thrown out of the `thread` tool from
		// inside a warning message.
		const threadList = Array.isArray(latest.threads) ? latest.threads : [];
		for (const raw of threadList) {
			const repairsBefore = dropped.length;
			const t = sanitizeThreadRecord(raw, dropped);
			if (t === undefined) {
				if (dropped.length === repairsBefore) {
					dropped.push(`thread record without a usable id: ${typeof raw === "object" ? "ignored" : typeof raw}`);
				}
				continue;
			}
			this.threads.set(t.id, t);
			// Old snapshots have no persisted counter. Derive its floor from every
			// surviving generated id before any new thread can claim an ordinal.
			const ordinal = canonicalThreadOrdinal(t.id);
			if (ordinal !== undefined) this.threadSeq = Math.max(this.threadSeq, ordinal);
		}
		const episodeList = Array.isArray(latest.episodes) ? latest.episodes : [];
		for (const raw of episodeList) {
			const e = sanitizeEpisodeRecord(raw, dropped);
			if (e === undefined) {
				dropped.push(`episode record without a usable id, thread id or file: ${typeof raw === "object" ? "ignored" : typeof raw}`);
				continue;
			}
			const safeFile = resolveEpisodeFile(ctx.cwd, e.file);
			if (safeFile === undefined) {
				dropped.push(`episode ${e.id}: file is missing, non-regular, or outside slate's episode directory`);
				continue;
			}
			const owner = this.threads.get(e.threadId);
			if (owner?.episodeId !== e.id) {
				dropped.push(`episode ${e.id}: owning thread does not reference this episode`);
				continue;
			}
			e.file = safeFile;
			this.episodes.set(e.id, e);
		}
		for (const thread of this.threads.values()) {
			if (thread.episodeId !== undefined && !this.episodes.has(thread.episodeId)) {
				this.threads.delete(thread.id);
				dropped.push(`thread ${thread.id}: its episode did not survive restoration`);
			}
		}
		if (dropped.length > 0 && ctx.hasUI) {
			ctx.ui.notify(`slate: dropped or repaired stale records:\n${dropped.join("\n")}`, "warning");
		}
		this.onDidChange?.();
	}
}

/**
 * Orchestrator spend recorded in the session file: billed LINEAGE spend —
 * summed over ALL entries including abandoned branches (forked/cloned sessions
 * thus inherit parent-file spend as their own). EXCLUDES pi-internal LLM calls
 * stored as non-message entries (compaction, branch summarization).
 * Shared by the widget (mode.ts) and handoff carry (handoff.ts).
 */
export function orchestratorCostUsd(ctx: ExtensionContext): number {
	let cost = 0;
	for (const entry of ctx.sessionManager.getEntries()) {
		// Loose cast + optional chaining: tolerate malformed/legacy entries.
		const e = entry as { type: string; message?: { role?: string; usage?: { cost?: { total?: number } } } };
		if (e.type === "message" && e.message?.role === "assistant") {
			cost += e.message.usage?.cost?.total ?? 0;
		}
	}
	return cost;
}
