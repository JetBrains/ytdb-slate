/**
 * Worker sessions: in-process pi SDK AgentSessions with the recursion guard.
 *
 * A worker loads NO skills, prompt templates, or themes (DefaultResourceLoader
 * no* options), and by default no project or discovered extensions. Slate
 * supplies internal reminder, nested-call lifecycle, and codemode components. The structural excludeTools guard
 * keeps orchestrator tools out (depth-1 guard). It inherits the HOST session's
 * project-trust state via an explicit SettingsManager, so untrusted projects get
 * neither project-local settings nor the project SYSTEM.md override in workers.
 *
 * When the host resolved a `workerExtensions` whitelist (worker-extensions.ts),
 * the loader runs in ALLOWLIST mode: noExtensions STAYS true — so auto-discovery
 * (slate itself included) never runs — while additionalExtensionPaths adds back
 * EXACTLY the resolved units and nothing else. The depth-1 guard is STRUCTURAL
 * (SE20): createAgentSession is given an excludeTools denylist of slate's
 * dispatch tools (thread/threads/episode), and the SDK re-applies that denylist
 * on every tool-registry refresh, so no worker can call them no matter when or
 * by whom they are registered — even a deferred before_agent_start registration.
 * The resolver's load-scoped barriers plus a best-effort post-load scan (RG2
 * below) additionally reject a unit that shadows a pi BUILT-IN at load time; a
 * deferred built-in shadow cannot be prevented from slate's side, exactly as it
 * cannot be for any extension in the host session.
 * Load units are ABSOLUTE paths (package directories or entry files), NEVER npm/
 * git specs (AD20): a spec resolves at temporary scope against a separate install
 * root, which would not reuse the host's installed copy and would attempt a
 * network install.
 *
 * Worker conversations persist under
 * <config dir>/slate/<runtime folder>/threads/*.jsonl (CONFIG_DIR_NAME, ".pi" by default)
 * and are reopened via SessionManager.open.
 */

import { resolve } from "node:path";
import {
	CONFIG_DIR_NAME,
	createAgentSession,
	DefaultResourceLoader,
	getAgentDir,
	SessionManager,
	SettingsManager,
	type ExtensionContext,
	type ExtensionFactory,
	type ModelRegistry,
	type ModelRuntime,
} from "@earendil-works/pi-coding-agent";
import { defaultArtifactFolder, ensureRuntimeDirectory } from "./slate-files.ts";
import { sanitizeForNotify } from "./notify.ts";
import { permitsSlateConfig } from "./config.ts";
import { loadPromptDocs } from "./prompt-docs.ts";
import type { LogicalModelEffort } from "./logical-model-definitions.ts";
import type { RecoveryCandidate } from "./logical-model-recovery.ts";
import { RequestThrottleAbort, type RequestThrottle } from "./request-throttle.ts";
import { createWorkerReminderRuntime } from "./worker-reminder.ts";
import { createWorkerNestedLifecycle } from "./worker-nested-lifecycle.ts";
import { describeSpecDefect, splitModelSpec, type SlateConfig, type ThreadType } from "./state.ts";
import { PI_BUILTIN_TOOL_NAMES, SLATE_TOOL_NAMES } from "./worker-extensions.ts";

export type WorkerSession = Awaited<ReturnType<typeof createAgentSession>>["session"] & {
	workerReminderHandledToolResult(): boolean;
	/** Close extension-managed Pi operation admission before terminal settlement. */
	closeManagedOperations(): void;
	/** Abort and join startup, admitted operations, and Pi idle state. */
	settleManagedOperations(): Promise<void>;
	/** Test and diagnostics view. Settled operations are removed immediately. */
	activeManagedOperationCount(): number;
	/** First failed admitted operation or Pi command after the startup boundary. */
	includedOperationFailure(): string | undefined;
	/** Start a new action without attributing completed startup work to it. */
	resetIncludedOperationFailure(): void;
	/** Emit worker session_shutdown once, then dispose even when a handler fails. */
	shutdownWorker(): Promise<void>;
};

export const DEFAULT_WORKER_TOOLS = ["read", "bash", "edit", "write", "grep", "find", "ls"];

/** Thread types that receive the reviewer charter and require findings structure. */
export const JUDGEMENT_THREAD_TYPES = ["reviewer", "adversarial"] as const satisfies readonly ThreadType[];

export function isJudgementThreadType(type: unknown): type is (typeof JUDGEMENT_THREAD_TYPES)[number] {
	return (JUDGEMENT_THREAD_TYPES as readonly unknown[]).includes(type);
}

// pi-ai 1.4.0 declares this value in
// @earendil-works/pi-ai/dist/api/openai-prompt-cache.js. pi's extension loader
// aliases the package root to the compat.js FILE, so an extension cannot safely
// import that deep subpath. The node test pins this copy to pi-ai's declaration.
export const OPENAI_PROMPT_CACHE_KEY_MAX_LENGTH = 64;

// Common writing guidance reaches every trusted worker configuration.
// Reviewer guidance is added only for judgement thread types.
export const WORKER_PREAMBLE = [
	"You are a worker thread executing ONE bounded action for an orchestrator.",
	"Do the action fully, then stop.",
	"Issue all independent tool calls simultaneously in one worker turn.",
	"Use separate turns only when results depend on each other or conflict.",
	"The harness runs calls issued in one turn at the same time. Cumulative token cost grows with the square of the number of turns because each turn resends the conversation history.",
	"Your final message must state: what you did, what you found, files you touched,",
	"and anything the orchestrator must know.",
	"When codemode is available, use one script to run independent tool calls together, chain dependent calls, or filter large output.",
	"Keep large intermediate data, such as copied text, in script variables instead of the context.",
	"Pi waits for script capacity. If a codemode script fails or does not start, call still-needed tools directly instead of resubmitting the script, even if an error suggests a retry. Apply the independent-call rule above to direct calls. A script that started may already have caused tool effects. Check the available execution evidence before you act. Do not blindly repeat calls that already ran.",
	"A codemode script can call only tools you can also call directly. Slate blocks every other tool named in the codemode description or a tool search.",
].join(" ");

export const WORKER_WRITING_GUIDANCE =
	"Use short, active sentences. Write sentences a non-native reader understands on one reading. Do not use semicolons or contractions. Apply these rules to your prose. Exclude research logs, worker task text, and the project's own agent instruction file. Describe only the current state in the README, docs, code comments and the project's own agent instruction file, not removed features or past behavior, but allow change records such as pull request descriptions, delivery commit bodies, release notes and issues to describe removals and past behavior.";

export const REVIEWER_CHARTER = `- Trace, don't guess: cite evidence from code actually read (file:line
  or diff hunk) for every claim about behavior. Read third-party /
  library code instead of assuming its semantics.
- Enumerate the cases along the changed execution paths that are in
  scope (branches, error paths, boundary values). Mark each case as
  checked or explicitly out of scope, and state the coverage gaps. For
  prose, enumerate the affected audiences, reader tasks, claims,
  definitions, cross-references, examples, exceptions, and boundary
  conditions instead of execution paths.
- Back every defect claim (blocker or major) with a concrete
  counterexample: the input, state, or interleaving that triggers the
  defect, traced through the code.
- Back every correctness claim ("no issue here") with a justification
  bounded to the scope you state, and say what the
  justification does not cover. For prose, use a bounded, reproducible
  check of the relevant set. Examples include checker output, targeted
  searches, re-resolved references, and comparison with authoritative
  sources. State explicitly what those checks cannot establish.
- Before finalizing, run an alternative-hypothesis check: "if the
  opposite verdict were true, what evidence would exist?" — then look
  for that evidence.
- When useful, log hypotheses explicitly (hypothesis → evidence sought
  → confirmed / refuted / refined) instead of wandering.
- Derive the final verdict from the evidence and claims above, not from
  overall impression.
- State the evidence that closes a finding, not only the evidence that
  opens one. A verdict that a finding is resolved carries its own
  evidence.
- Treat a fix series as a changed artifact that needs review. Verify the
  addressed finding, then review the fix diff and the cumulative result
  for new paths, claims, and regressions. Clearing the original finding
  does not clear defects introduced by its fix.
- Structured reasoning can be confidently wrong when a case is missed.
  State coverage gaps rather than implying completeness. These
  arguments carry no formal guarantee and do not replace running the
  project's checks.
`;

export function workerPreamble(trusted: boolean, reviewerCharter: boolean): string {
	const prose = trusted ? `${WORKER_PREAMBLE} ${WORKER_WRITING_GUIDANCE}` : WORKER_PREAMBLE;
	return reviewerCharter === true ? `${prose}\n${REVIEWER_CHARTER}` : prose;
}

/** Immutable change-level guidance. Action paths belong in hidden action context. */
export function changeGuidance(change: string | undefined, review: boolean): string {
	if (change === undefined) return review
		? "No change is open. Do not write workflow records.\nA no-change review is outside the workflow temporary-file rule. Write only your own writing-checker diff in a private operating-system temporary folder outside the checkout.\nDelete the diff and its private folder after use. Write nothing else."
		: "No change is open. Do not write workflow records.\nIf no action folder is supplied, create no scratch file in the checkout and pause any record write.";
	const header = `Change folder: slate-changes/${change}\n`;
	return header + (review
		? "Write only your own writing-checker diff in the supplied action folder. Write nothing else.\nDelete the diff before finishing.\nIf no action folder is supplied, create no scratch file in the checkout and pause the checker diff."
		: "Put assigned drafts, designs, records, and other lasting files in the change folder under safe-write rules.\n" +
			"Put scratch files in the supplied action folder, except for required outside-checkout folders.\n" +
			"A project rule or verification tool requiring an outside-checkout folder takes precedence.\n" +
			"The tool keeps its own private folder under its own deletion and retention rules.\n" +
			"This exception gives no alternate destination for start copies or payloads.\n" +
			"For your record-write files:\nDelete your files after your record check passes.\n" +
			"For scratch files without a record:\nDelete your scratch files before you finish.\n" +
			"If no action folder is supplied, create no scratch file in the checkout and pause any record write.");
}

export function workerSystemPromptBlocks(trusted: boolean, reviewerCharter: boolean, reviewGuidance: string | undefined, promptDocs: string[], changeGuidance?: string): string[] {
	return [workerPreamble(trusted, reviewerCharter), ...(changeGuidance === undefined ? [] : [changeGuidance]), ...(reviewGuidance === undefined ? [] : [reviewGuidance]), ...promptDocs];
}

export function threadsDir(cwd: string, runtimeFolder = defaultArtifactFolder()): string {
	return resolve(cwd, CONFIG_DIR_NAME, "slate", runtimeFolder, "threads");
}

function installPromptCacheKey(session: WorkerSession, promptCacheKey?: string): void {
	const previous = session.agent.onPayload;
	session.agent.onPayload = async (payload, model) => {
		let chainedPayload = payload;
		try {
			const result = await previous?.(payload, model);
			if (result !== undefined && result !== null) chainedPayload = result;
		} catch {
			return payload;
		}

		try {
			// pi-ai 1.4.0 api/openai-responses.js buildParams always creates
			// prompt_cache_key and assigns undefined when resolved cacheRetention is
			// "none". Own-property presence therefore distinguishes that deliberate
			// opt-out from a payload shape that never considered this field.
			const platformDisabledCache =
				typeof payload === "object" &&
				payload !== null &&
				Object.prototype.hasOwnProperty.call(payload, "prompt_cache_key") &&
				(payload as Record<string, unknown>).prompt_cache_key === undefined;
			const chainedDisabledCache =
				typeof chainedPayload === "object" &&
				chainedPayload !== null &&
				Object.prototype.hasOwnProperty.call(chainedPayload, "prompt_cache_key") &&
				(chainedPayload as Record<string, unknown>).prompt_cache_key === undefined;
			if (
				promptCacheKey === undefined ||
				model.api !== "openai-responses" ||
				platformDisabledCache ||
				chainedDisabledCache ||
				Array.from(promptCacheKey).length > OPENAI_PROMPT_CACHE_KEY_MAX_LENGTH ||
				typeof chainedPayload !== "object" ||
				chainedPayload === null
			) {
				return chainedPayload;
			}
			(chainedPayload as Record<string, unknown>).prompt_cache_key = promptCacheKey;
			return chainedPayload;
		} catch {
			return chainedPayload;
		}
	};
}

/** The SDK's own stream-function type, read off the session so slate cannot drift from it. */
type WorkerStreamFunction = WorkerSession["agent"]["streamFunction"];

export const WORKER_REQUEST_CONTRACT_ERROR = "Slate route contract violation.";
const WORKER_LIFECYCLE_CLOSED_ERROR = "Slate worker lifecycle is closed.";

export interface WorkerRequestContract {
	/** Aborted exactly once when lifecycle ownership ends. Pacing waits observe it. */
	readonly invalidationSignal: AbortSignal;
	expect(candidate: Pick<RecoveryCandidate, "provider" | "model" | "effort">): void;
	invalidate(): void;
	latestAccepted(): { model: { provider: string; id: string }; effort: LogicalModelEffort } | undefined;
	/**
	 * The refusal message of this action, when one attempted request was refused.
	 *
	 * The owner of the action reads this at one place instead of watching each
	 * event position. A caller cancellation is not a refusal, because the caller
	 * asked for the stop. A lifecycle invalidation that no request reached is not
	 * a refusal either, because no request was attempted.
	 *
	 * The first refused request is TERMINAL for its action: `accept` blocks every
	 * later request of the same owner, including a request that carries the pair
	 * the owner now expects.
	 */
	refusal(): string | undefined;
	accept<T>(
		model: { provider?: unknown; id?: unknown },
		reasoning: unknown,
		signal: AbortSignal | undefined,
		handoff: () => T,
	): T;
}

/** One action-local request owner. It stores only the latest accepted pair. */
export function createWorkerRequestContract(): WorkerRequestContract {
	let active = true;
	let expected: { provider: string; model: string; effort: LogicalModelEffort } | undefined;
	let latest: { model: { provider: string; id: string }; effort: LogicalModelEffort } | undefined;
	let refused: string | undefined;
	const invalidation = new AbortController();
	const fail = (): never => { throw new Error(WORKER_REQUEST_CONTRACT_ERROR); };
	// One attempted request was blocked here. The message is constant, so a later
	// refusal cannot replace the first one with different text.
	const refuse = (): never => { refused = WORKER_REQUEST_CONTRACT_ERROR; return fail(); };
	return {
		invalidationSignal: invalidation.signal,
		expect(candidate) {
			if (!active) fail();
			expected = { provider: candidate.provider, model: candidate.model, effort: candidate.effort };
		},
		invalidate() {
			if (!active) return;
			active = false;
			expected = undefined;
			invalidation.abort();
		},
		latestAccepted() {
			return latest === undefined ? undefined : { model: { ...latest.model }, effort: latest.effort };
		},
		refusal() {
			return refused;
		},
		accept(model, reasoning, signal, handoff) {
			const actualEffort = reasoning === undefined ? "off" : reasoning;
			const current = expected;
			// Caller cancellation keeps its own identity and records no refusal.
			if (signal?.aborted === true) return fail();
			// TERMINAL LATCH: one refused request ends this action. A later request may
			// not continue it, not even with the pair this owner now expects, and
			// whichever position or continuation sends it. The recorded refusal and the
			// latest accepted pair both stay unchanged.
			if (refused !== undefined) return fail();
			if (!active || current === undefined) return refuse();
			if (model.provider !== current.provider || model.id !== current.model || actualEffort !== current.effort) return refuse();
			const value = handoff();
			latest = {
				model: { provider: current.provider, id: current.model },
				effort: current.effort,
			};
			return value;
		},
	};
}

/**
 * Put the session's request throttle in front of every provider request.
 *
 * WHY THE STREAM FUNCTION, and not `onPayload`:
 *  · the stream function receives the run's ABORT SIGNAL in its options, so the
 *    wait can be cancelled; `onPayload` receives only a payload and a model
 *    (pi-ai types.d.ts), so a wait there could not be cancelled;
 *  · pi's history compaction and branch summarization call
 *    `this.agent.streamFunction` directly (pi-coding-agent
 *    dist/core/agent-session.js lines 1453 and 2551) and their options are built
 *    WITHOUT `onPayload` (dist/core/compaction/compaction.js
 *    createSummarizationOptions), so a throttle on `onPayload` would miss every
 *    worker history summary, which the approved design includes;
 *  · the wait happens BEFORE the SDK converts the conversation into a provider
 *    payload, so a waiting request holds no converted copy (PF5).
 *
 * The wrapper preserves the software development kit (SDK) authentication branch.
 * AgentSession._getSummarizationRequestAuth takes its strict branch only when
 * agent.streamFunction === streamSimple. In pinned pi 1.4.0, createAgentSession
 * installs its own stream function, so fresh worker sessions take the lenient
 * branch. test/request-throttle-worker.test.ts checks that identity.
 *
 * A THROWN admission error is NOT swallowed. A cancelled wait rejects, pi turns
 * the rejection into the same aborted or errored assistant outcome it produces
 * for a provider failure (pi-agent-core dist/agent.js handleRunFailure), and no
 * request is sent.
 */
export function installRequestThrottle(
	session: WorkerSession,
	throttle: RequestThrottle,
	contract?: WorkerRequestContract,
): void {
	const previous: WorkerStreamFunction = session.agent.streamFunction;
	const handoff = (model: Parameters<WorkerStreamFunction>[0], context: Parameters<WorkerStreamFunction>[1], options: Parameters<WorkerStreamFunction>[2]) =>
		contract === undefined
			? previous(model, context, options)
			: contract.accept(model, options?.reasoning, options?.signal, () => previous(model, context, options));
	session.agent.streamFunction = (model, context, options) => {
		const requestSignal = options?.signal;
		const waitSignal = contract === undefined
			? requestSignal
			: requestSignal === undefined
				? contract.invalidationSignal
				: AbortSignal.any([requestSignal, contract.invalidationSignal]);
		const pending = throttle.accept(model, waitSignal, () => handoff(model, context, options));
		if (contract === undefined) return pending;
		return pending.catch((error: unknown) => {
			// Lifecycle invalidation owns this wake-up. Keep Pi's caller abort distinct.
			if (error instanceof RequestThrottleAbort && contract.invalidationSignal.aborted && requestSignal?.aborted !== true) {
				throw new Error(WORKER_REQUEST_CONTRACT_ERROR);
			}
			throw error;
		});
	};
}

export function installWorkerRequestContract(session: WorkerSession, contract: WorkerRequestContract): void {
	const previous: WorkerStreamFunction = session.agent.streamFunction;
	session.agent.streamFunction = (model, context, options) =>
		contract.accept(model, options?.reasoning, options?.signal, () => previous(model, context, options));
}

/**
 * Resolve a "provider/id" model string against the registry; throws a clear error
 * if unknown. Validation and splitting are the shared helpers (CQ2), so the
 * message now names WHY a spec is malformed — including invisible characters,
 * which an "unknown model" error could never have explained.
 */
export function resolveModel(ctx: ExtensionContext, spec: string) {
	const parts = splitModelSpec(spec);
	if (!parts) throw new Error(`Invalid model spec "${spec}" — ${describeSpecDefect(spec)}`);
	const model = ctx.modelRegistry.find(parts.provider, parts.id);
	if (!model) throw new Error(`Unknown model "${spec}" — not found in the model registry`);
	return model;
}

function providerInheritanceError(providerId?: string): Error {
	const suffix = providerId === undefined ? "" : ` for provider "${sanitizeForNotify(providerId, 80)}"`;
	return new Error(`slate: worker provider inheritance failed${suffix}. No provider configuration details were reported.`);
}

/**
 * Copy host extension provider registrations that the constructed worker did
 * not realize itself. The registered-provider roster is the public union of
 * native and config registrations. Built-in providers are outside that roster,
 * so a host extension override of a built-in still crosses this boundary.
 *
 * @internal
 * Internal helper. Direct imports are not a supported interface.
 */
export function inheritHostProviderRegistrations(
	host: Pick<
		ModelRegistry,
		"getRegisteredProviderIds" | "getRegisteredProviderConfig" | "getRegisteredNativeProvider"
	>,
	worker: ModelRuntime,
): void {
	let hostIds: readonly string[];
	try {
		hostIds = host.getRegisteredProviderIds();
	} catch {
		throw providerInheritanceError();
	}

	let workerIds: Set<string>;
	let providerIds: string[];
	try {
		workerIds = new Set(worker.getRegisteredProviderIds());
		providerIds = [...new Set(hostIds)];
		if (providerIds.some((providerId) => typeof providerId !== "string" || providerId.trim() === "")) {
			throw providerInheritanceError();
		}
		providerIds.sort();
	} catch {
		throw providerInheritanceError();
	}

	for (const providerId of providerIds) {
		if (workerIds.has(providerId)) continue;

		try {
			const native = host.getRegisteredNativeProvider(providerId);
			const config = native === undefined ? host.getRegisteredProviderConfig(providerId) : undefined;
			if (native !== undefined) worker.registerNativeProvider(native);
			else if (config !== undefined) worker.registerProvider(providerId, config);
			else throw providerInheritanceError(providerId);

			const registered = new Set(worker.getRegisteredProviderIds());
			const copiedFormIsPresent = native !== undefined
				? worker.getRegisteredNativeProvider(providerId) === native
				: worker.getRegisteredProviderConfig(providerId) !== undefined;
			const compositionError = worker.getError()?.includes(`Provider "${providerId}":`) === true;
			if (!registered.has(providerId) || !copiedFormIsPresent || worker.getProvider(providerId) === undefined || compositionError) {
				throw providerInheritanceError(providerId);
			}
			workerIds.add(providerId);
		} catch {
			throw providerInheritanceError(providerId);
		}
	}
}

// One load result belongs to this opener module, including a rejected import.
let workerCodemodeLoad: Promise<typeof import("./worker-codemode.ts")> | undefined;

export async function openWorkerSession(opts: {
	ctx: ExtensionContext;
	sessionFile?: string; // resume when provided, else create new under this runtime folder
	runtimeFolder?: string;
	// Episode and observation paths do not belong here. Their shared artifact writer owns persistence.
	model?: string; // "provider/id"
	tools?: string[];
	promptDocs?: string[]; // role-guideline doc paths, cwd-relative (default none)
	config?: SlateConfig; // loader identity permits home-only settings without project trust
	extensionPaths?: string[]; // absolute worker-extension load units (package dirs or entry files); default none
	extensionToolNames?: string[]; // host-selected names, including tools registered during host session_start
	reviewerCharter?: boolean; // thread-role decision from ThreadManager; only literal true enables the charter
	reviewGuidance?: string; // complete selected implementation instructions, loaded before thread creation
	changeGuidance?: string; // immutable captured change-level rules, without an action path
	promptCacheKey?: string; // the main session's shared OpenAI Responses cache-routing key
	requestThrottle?: RequestThrottle; // the main session's shared per-model request throttle
	requestContract?: WorkerRequestContract; // action-local expected pair and accepted attribution
	/** Internal test seam for the fixed nested-settlement diagnostic interval. */
	testOnlyNestedWarningMs?: number;
	report?: (message: string) => void; // lifecycle failures visible to the dispatch and host
	onCreated?: (session: WorkerSession) => void; // publish ownership and install capture before session_start begins
	deferShutdownOnOpenFailure?: boolean; // ThreadManager persists captured startup facts before shutdown
}): Promise<WorkerSession> {
	const { ctx } = opts;
	const agentDir = getAgentDir();

	// Trust propagation (mirrors vanilla pi's runtime SettingsManager): when no
	// settingsManager is passed, the SDK default-constructs one with
	// projectTrusted=true, which would make workers honor project-local
	// settings and the <config dir>/SYSTEM.md override even in projects the
	// user has NOT trusted. Carry the host session's actual trust decision into
	// both the resource loader and the session.
	//
	// READ-ONLY view (AF8/AF9): pi 1.4.0 keeps ordinary session.setModel and
	// setThinkingLevel calls inside the session. Slate requests no persistence.
	// This storage protects global settings from calls with persist:true and
	// from hosts that persist switches. A file-backed manager would save those
	// explicit writes as global defaults, including a worker's failover choice.
	// Snapshot the settings once and serve them through a custom SettingsStorage.
	// Its withLock discards the callback's return value, which drops writes.
	// persistScopedSettings returns the new JSON through that callback.
	// Reads, merge semantics and trust gating match a file-backed manager.
	//
	// CN4: a throwaway file-backed SettingsManager takes the snapshot under pi's
	// settings lock. Pi holds that lock during its non-atomic settings writes.
	// A call with persist:true or a direct SettingsManager setter can write
	// global defaults. An unlocked read could capture an incomplete write.
	// The throwaway manager reads under the lock and handles read errors.
	// Its per-scope snapshots become JSON for the storage below.
	// fromStorage parses and migrates that JSON again without changing it.
	// The throwaway manager never writes because no caller invokes its setters.
	const trusted = ctx.isProjectTrusted();
	const snapshot = SettingsManager.create(ctx.cwd, agentDir, { projectTrusted: trusted });
	// Pi's background warmer bypasses agent.streamFunction and therefore Slate's
	// request admission. Disable it before session creation in this worker-only
	// global view. Project overrides cannot enable this global-only setting.
	const globalJson = JSON.stringify({ ...snapshot.getGlobalSettings(), cacheWarming: "off" });
	const projectJson = JSON.stringify(snapshot.getProjectSettings());
	const settingsManager = SettingsManager.fromStorage(
		{
			withLock(scope, fn) {
				fn(scope === "global" ? globalJson : projectJson); // return discarded → writes dropped
			},
		},
		{ projectTrusted: trusted },
	);

	// Role-guideline doc content is captured when this session object is
	// created: a live session keeps its system prompt until disposed; a
	// thread reopened later (e.g. after a pi restart) re-reads the docs at
	// their then-current content. Blocks go in separator-free — pi core
	// joins appendSystemPrompt entries with "\n\n". A standalone caller still
	// needs project trust. Only the loader can authorize a home-only view.
	const configPermitted = permitsSlateConfig(opts.config, trusted);
	const docPaths = trusted ? opts.promptDocs : opts.config?.workerPromptDocs;
	const promptDocs = configPermitted ? loadPromptDocs(ctx.cwd, docPaths ?? []) : [];
	// Absolute units come from the host resolver, never from JSON path fields.
	// Pi still controls which extensions are present in the host registry.
	const extensionPaths = configPermitted ? (opts.extensionPaths ?? []) : [];
	const workerReminder = createWorkerReminderRuntime();
	const warn = (msg: string, notifyHost = false) => {
		let retained = false;
		try {
			if (opts.report) { opts.report(msg); retained = true; }
		} catch { /* fall back when the report sink rejects the warning */ }
		if ((!opts.report || notifyHost) && ctx.hasUI) {
			try { ctx.ui.notify(msg, "warning"); return; } catch { /* a replaced host context can reject notification */ }
		}
		if (!retained) {
			try { console.warn(msg); } catch { /* no remaining reporting channel */ }
		}
	};
	const nestedLifecycle = createWorkerNestedLifecycle(message => warn(message, true), opts.testOnlyNestedWarningMs);
	let codemodePath: string | undefined;
	let codemodeName: string | undefined;
	let codemodeFactory: ExtensionFactory | undefined;
	let codemodeFailure: unknown;
	try {
		if (!workerCodemodeLoad) workerCodemodeLoad = import("./worker-codemode.ts");
		const codemode = await workerCodemodeLoad;
		if (codemode.WORKER_CODEMODE_COMPONENT_NAME !== "slate-worker-codemode"
			|| typeof codemode.createWorkerCodemodeComponent !== "function") {
			throw new Error("Invalid worker codemode component exports");
		}
		const factory = codemode.createWorkerCodemodeComponent(warn);
		if (typeof factory !== "function") throw new Error("Invalid worker codemode component factory");
		codemodeName = codemode.WORKER_CODEMODE_COMPONENT_NAME;
		codemodePath = `<inline:${codemodeName}>`;
		codemodeFactory = factory;
	} catch (error) {
		codemodeFailure = error;
	}
	const loader = new DefaultResourceLoader({
		cwd: ctx.cwd,
		agentDir,
		settingsManager,
		// Recursion guard (D7): auto-discovery stays OFF. additionalExtensionPaths
		// runs the loader in allowlist mode — noExtensions keeps every
		// auto-discovered extension out (slate included) while these absolute units
		// are the only ones added back (AD20 — see the module header on why paths,
		// never specs). undefined when empty so the default worker is untouched.
		noExtensions: true,
		additionalExtensionPaths: extensionPaths.length > 0 ? extensionPaths : undefined,
		extensionFactories: [
			{
				name: "slate-worker-reminder",
				factory: workerReminder.extension,
				hidden: true,
			},
			...(codemodeFactory === undefined ? [] : [{
				name: codemodeName!,
				factory: codemodeFactory,
				hidden: true,
			}]),
			{
				name: "slate-worker-nested-lifecycle",
				factory: nestedLifecycle.extension,
				hidden: true,
			},
		],
		noSkills: true,
		noPromptTemplates: true,
		noThemes: true,
		// Writing guidance follows permitted Slate settings. The reviewer
		// charter is not trust-gated because it is slate's own constant.
		appendSystemPrompt: workerSystemPromptBlocks(configPermitted, opts.reviewerCharter === true, opts.reviewGuidance, promptDocs, opts.changeGuidance),
	});
	await loader.reload();
	const loaded = loader.getExtensions();
	// Codemode load failures get their own warning. Other loader errors also warn.
	for (const err of loaded.errors ?? []) {
		if (err.path === codemodePath) { codemodeFailure = err.error; continue; }
		warn(`slate: worker extension failed to load — ${sanitizeForNotify(String(err.path))}: ${sanitizeForNotify(String(err.error))}`);
	}
	const ownedCodemode = codemodeFailure === undefined && (loaded.extensions ?? []).some(ext =>
		ext.path === codemodePath && ext.tools instanceof Map && ext.tools.has("codemode"));
	if (!ownedCodemode) {
		const reason = codemodeFailure instanceof Error ? codemodeFailure.message : String(codemodeFailure ?? "internal component did not register codemode");
		warn(`slate: codemode is unavailable for this worker — ${sanitizeForNotify(reason)}`);
	}

	// Extension tool names actually registered by the whitelisted units — needed
	// both for the collision re-check and for the tools allowlist below. Stays
	// empty (and this whole block is skipped) unless a whitelist was resolved.
	const extensionToolNames: string[] = [];
	if (extensionPaths.length > 0) {
		// Collect the tool names each loaded extension actually registered. Loose
		// cast + Map guard: tolerate a malformed extensions/tools shape (state.ts
		// pattern).
		const collisions: string[] = [];
		for (const ext of loaded.extensions ?? []) {
			const e = ext as unknown as { path?: unknown; tools?: unknown };
			if (!(e.tools instanceof Map)) continue;
			for (const name of e.tools.keys()) {
				if (typeof name !== "string" || name === "") continue;
				extensionToolNames.push(name);
				// LOAD-TIME collision scan (RG2), BEST-EFFORT: it sees only what the
				// extensions registered DURING loader.reload(). A deferred registration
				// (e.g. from a before_agent_start handler on the worker's first prompt)
				// is invisible here — and is equally available to any extension the host
				// session runs, so it is outside slate's control. slate's OWN invariant
				// does NOT rely on this scan: thread/threads/episode are denied
				// structurally by the excludeTools denylist on createAgentSession below
				// (re-applied on every tool-registry refresh), so no worker can call them
				// whenever they are registered. For a pi BUILT-IN there is no such
				// gap-closer (the worker needs the real built-in), so this scan catches a
				// LOAD-TIME shadow and fails the dispatch closed; a deferred shadow cannot
				// be prevented.
				if (SLATE_TOOL_NAMES.includes(name) || PI_BUILTIN_TOOL_NAMES.includes(name) || (name === "codemode" && e.path !== codemodePath)) {
					const path = typeof e.path === "string" ? e.path : "extension";
					collisions.push(`${sanitizeForNotify(path)} → "${sanitizeForNotify(name)}"`);
				}
			}
		}
		if (collisions.length > 0) {
			// Thrown BEFORE createAgentSession below, so no worker session is leaked.
			throw new Error(
				`slate: refusing to open worker — whitelisted extension(s) register tool(s) that would overwrite a slate or pi built-in tool: ${collisions.join(", ")}`,
			);
		}
	}

	const model = opts.model ? resolveModel(ctx, opts.model) : ctx.model;

	// Pi writes the transcript itself. Check its entire parent chain immediately
	// before passing the folder to Pi, including existing symlinks above threads.
	const sessionManager = opts.sessionFile
		? SessionManager.open(opts.sessionFile)
		: SessionManager.create(ctx.cwd, ensureRuntimeDirectory(ctx.cwd, opts.runtimeFolder ?? defaultArtifactFolder(), "threads"));

	// In pi 1.4.0, createAgentSession creates a ModelRuntime when none is passed.
	// It uses auth.json, models.json and models-store.json under agentDir.
	// SDK creation enables network catalog refresh only with allowModelNetwork.
	// This call supplies no runtime option, so creation uses no network catalog
	// refresh. PI_OFFLINE also disables model-network access.
	const baseTools = opts.tools && opts.tools.length > 0 ? opts.tools : DEFAULT_WORKER_TOOLS;
	const modifierTools = baseTools.every(name => name.startsWith("+") || name.startsWith("-"));
	const isCodemode = (name: string) => /^(?:[+-])?codemode$/.test(name);
	const appendedTools = [
		...extensionToolNames,
		...(extensionPaths.length > 0 ? (opts.extensionToolNames ?? []) : []),
	].filter(name => !isCodemode(name));
	if (ownedCodemode) appendedTools.push("codemode");
	const workerTools = [...new Set([
		...baseTools.filter(name => !isCodemode(name)),
		...appendedTools.map(name => modifierTools ? `+${name}` : name),
	])];
	const { session } = await createAgentSession({
		cwd: ctx.cwd,
		agentDir,
		model: model ?? undefined,
		// Explicit thinkingLevel (AF9): a live failover to a weaker model
		// re-clamps the thinking level and appends thinking_level_change to the
		// worker's session file; on reopen the SDK restores that clamped value
		// (resolution: explicit option > session file > settings default), which
		// would permanently downgrade the thread after the mapped model is
		// abandoned. Passing the settings default explicitly on every open makes
		// the SDK re-clamp against the CURRENT model instead. "medium" mirrors
		// the SDK's DEFAULT_THINKING_LEVEL (not exported).
		thinkingLevel: settingsManager.getDefaultThinkingLevel() ?? "medium",
		// workerTools / the per-dispatch `tools` argument govern the BUILT-IN tools
		// only; pi's allowlist gates extension tools too, so the whitelisted
		// extensions' registered tool names are unioned in (de-duplicated) — without
		// this the extensions would load but stay inert (present in the registry,
		// absent from the active set). Only the owned component can add codemode.
		tools: workerTools,
		// STRUCTURAL depth-1 guard (SE20): slate's dispatch tools are denied to EVERY
		// worker session. excludeTools applies AFTER the allowlist and the SDK
		// re-applies it on every tool-registry refresh, so a tool named
		// thread/threads/episode is filtered out no matter when it is registered
		// (including a deferred before_agent_start registration) — a worker can never
		// re-enter the orchestrator's dispatch surface (D7).
		excludeTools: ownedCodemode ? SLATE_TOOL_NAMES : [...SLATE_TOOL_NAMES, "codemode"],
		resourceLoader: loader,
		sessionManager,
		settingsManager,
	});
	let lifecyclePhase: "startup" | "running" | "shutdown" = "startup";
	const startupErrors: string[] = [];
	let startupPromise: Promise<void> | undefined;
	let settlementPromise: Promise<void> | undefined;
	let shutdownPromise: Promise<void> | undefined;
	let managedAdmissionOpen = true;
	const activeManagedOperations = new Set<Promise<unknown>>();
	const startupManagedOperations = new Set<Promise<unknown>>();
	let includedFailure: string | undefined;
	const extensionError = (error: { extensionPath: string; event: string; error: string }) => {
		if (
			!managedAdmissionOpen &&
			(error.event === "send_message" || error.event === "send_user_message") &&
			error.error === WORKER_LIFECYCLE_CLOSED_ERROR
		) return;
		const detail = `${sanitizeForNotify(error.extensionPath)} (${sanitizeForNotify(error.event)}): ${sanitizeForNotify(error.error)}`;
		// Attribute an error to the event that produced it. Host teardown can change
		// lifecyclePhase while an async session_start handler is still running.
		const phase = error.event === "session_start" ? "startup" : lifecyclePhase;
		if (phase === "startup") startupErrors.push(detail);
		if (phase === "running" && error.event === "command") {
			includedFailure ??= `slate: worker extension running failed — ${detail}`;
		}
		warn(`slate: worker extension ${phase} failed — ${detail}`);
	};
	const workerSession = Object.assign(session, {
		workerReminderHandledToolResult: workerReminder.handledToolResult,
		closeManagedOperations(): void {
			managedAdmissionOpen = false;
			nestedLifecycle.close();
		},
		activeManagedOperationCount(): number {
			return activeManagedOperations.size;
		},
		includedOperationFailure(): string | undefined {
			return includedFailure;
		},
		resetIncludedOperationFailure(): void {
			includedFailure = undefined;
		},
		settleManagedOperations(): Promise<void> {
			if (settlementPromise !== undefined) return settlementPromise;
			settlementPromise = Promise.resolve().then(async () => {
				try { await session.abort(); } catch { /* classification uses captured messages */ }
				try { await startupPromise; } catch { /* startup failure remains independently visible */ }
				while (activeManagedOperations.size > 0) {
					await Promise.allSettled([...activeManagedOperations]);
				}
				try { await session.waitForIdle(); } catch { /* shutdown still runs */ }
				try { await nestedLifecycle.join(); } finally { nestedLifecycle.clearWarning(); }
			});
			workerSession.closeManagedOperations();
			nestedLifecycle.startWarning();
			return settlementPromise;
		},
		shutdownWorker(): Promise<void> {
			if (shutdownPromise !== undefined) return shutdownPromise;
			lifecyclePhase = "shutdown";
			shutdownPromise = (async () => {
				await workerSession.settleManagedOperations();
				try {
					await session.extensionRunner.emit({ type: "session_shutdown", reason: "quit" });
				} catch (error) {
					warn(`slate: worker extension shutdown failed — ${sanitizeForNotify(error instanceof Error ? error.message : String(error))}`);
				} finally {
					try {
						session.dispose();
					} catch (error) {
						warn(`slate: worker session disposal failed — ${sanitizeForNotify(error instanceof Error ? error.message : String(error))}`);
					}
				}
			})();
			return shutdownPromise;
		},
	});
	const managedClosedError = () => new Error(WORKER_LIFECYCLE_CLOSED_ERROR);
	const managedMethods = session as WorkerSession & {
		sendUserMessage?: WorkerSession["sendUserMessage"];
		sendCustomMessage?: WorkerSession["sendCustomMessage"];
	};
	const originalSendUserMessage = managedMethods.sendUserMessage?.bind(session);
	const originalSendCustomMessage = managedMethods.sendCustomMessage?.bind(session);
	const trackManaged = <T>(start: () => Promise<T>): Promise<T> => {
		if (!managedAdmissionOpen) return Promise.reject(managedClosedError());
		let operation: Promise<T>;
		try { operation = start(); } catch (error) { operation = Promise.reject(error); }
		activeManagedOperations.add(operation);
		if (lifecyclePhase === "startup") startupManagedOperations.add(operation);
		void operation.then(
			() => { activeManagedOperations.delete(operation); startupManagedOperations.delete(operation); },
			(error: unknown) => {
				activeManagedOperations.delete(operation);
				startupManagedOperations.delete(operation);
				if (lifecyclePhase === "running") includedFailure ??= `included message call failed: ${sanitizeForNotify(error instanceof Error ? error.message : String(error))}`;
			},
		);
		return operation;
	};
	if (originalSendUserMessage !== undefined) {
		session.sendUserMessage = ((...args: Parameters<typeof session.sendUserMessage>) =>
			trackManaged(() => originalSendUserMessage(...args))) as typeof session.sendUserMessage;
	}
	if (originalSendCustomMessage !== undefined) {
		session.sendCustomMessage = ((...args: Parameters<typeof session.sendCustomMessage>) =>
			trackManaged(() => originalSendCustomMessage(...args))) as typeof session.sendCustomMessage;
	}
	if (opts.promptCacheKey !== undefined) installPromptCacheKey(workerSession, opts.promptCacheKey);
	// Installed INDEPENDENTLY of the cache key above: the two switches are
	// separate, so a project may keep either one without the other.
	if (opts.requestThrottle !== undefined) installRequestThrottle(workerSession, opts.requestThrottle, opts.requestContract);
	else if (opts.requestContract !== undefined) installWorkerRequestContract(workerSession, opts.requestContract);

	// bindExtensions has not installed its listener yet. Keep cleanup errors
	// visible if provider inheritance fails in this partial-startup window.
	const stopEarlyExtensionErrors = typeof session.extensionRunner.onError === "function"
		? session.extensionRunner.onError(extensionError)
		: () => {};
	try {
		// Worker extension registrations flush during AgentSession construction.
		// Compare the realized union only after createAgentSession returns and
		// before extension startup can select a route or issue the first request.
		inheritHostProviderRegistrations(ctx.modelRegistry, session.modelRuntime);
	} catch (error) {
		await workerSession.shutdownWorker();
		throw error;
	}
	stopEarlyExtensionErrors();

	let beginStartup!: () => void;
	const startupGate = new Promise<void>((resolve) => { beginStartup = resolve; });
	startupPromise = startupGate.then(async () => {
		// createAgentSession loads extension factories but does not emit session_start.
		// Binding completes startup and refreshes tools registered by those handlers.
		await session.bindExtensions({ mode: "print", onError: extensionError });
		// A startup handler may start a message call without awaiting it. Its
		// follow-up handlers may admit more calls while the startup phase is open.
		// Keep the phase open through Pi idle and drain the whole admitted chain.
		while (true) {
			while (startupManagedOperations.size > 0) {
				await Promise.allSettled([...startupManagedOperations]);
			}
			await session.waitForIdle?.();
			if (startupManagedOperations.size === 0) break;
		}
		if (startupErrors.length > 0) {
			throw new Error(`slate: worker extension startup did not complete: ${startupErrors.join("; ")}`);
		}

		// The selected unit maps are live. Re-scan after session_start so a deferred
		// registration cannot replace a Slate or pi built-in before the first prompt.
		const startupCollisions: string[] = [];
		for (const ext of loaded.extensions ?? []) {
			const candidate = ext as unknown as { path?: unknown; tools?: unknown };
			if (!(candidate.tools instanceof Map)) continue;
			for (const name of candidate.tools.keys()) {
				if (typeof name !== "string" || (!SLATE_TOOL_NAMES.includes(name) && !PI_BUILTIN_TOOL_NAMES.includes(name) && !(name === "codemode" && candidate.path !== codemodePath))) continue;
				const path = typeof candidate.path === "string" ? candidate.path : "extension";
				startupCollisions.push(`${sanitizeForNotify(path)} → "${sanitizeForNotify(name)}"`);
			}
		}
		if (startupCollisions.length > 0) {
			throw new Error(
				`slate: refusing to start worker — selected extension(s) registered tool(s) during startup that overwrite a slate or pi built-in tool: ${startupCollisions.join(", ")}`,
			);
		}
		if (shutdownPromise === undefined) lifecyclePhase = "running";
	});
	// The action installs its event capture before session_start can submit work.
	opts.onCreated?.(workerSession);
	beginStartup();
	try {
		await startupPromise;
		return workerSession;
	} catch (error) {
		workerSession.closeManagedOperations();
		await workerSession.settleManagedOperations();
		if (opts.deferShutdownOnOpenFailure !== true) await workerSession.shutdownWorker();
		throw error;
	}
}
