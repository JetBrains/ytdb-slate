export const LOGICAL_MODEL_EFFORTS = ["off", "minimal", "low", "medium", "high", "xhigh", "max"] as const;
export type LogicalModelEffort = (typeof LOGICAL_MODEL_EFFORTS)[number];

export type LogicalFieldSource = {
	publisher: "DeepSWE/DataCurve";
	retrieved: "2026-09-11";
	sourceUrl: "https://deepswe.datacurve.ai/artifacts/v1.1/leaderboard-live.json";
	basis: "Project judgment informed by DeepSWE v1.1 and reviewed supporting evidence";
} | {
	publisher: "Slate project";
	decided: "2026-09-30";
	basis: "Project judgment set on 2026-09-30 without new benchmark evidence";
};

export interface LogicalModelSource {
	capabilityRating?: Readonly<LogicalFieldSource>;
	costRating?: Readonly<LogicalFieldSource>;
	guidelines?: Readonly<LogicalFieldSource>;
}

export interface LogicalModelDefinition {
	model: string;
	capabilityRating: number;
	effort: LogicalModelEffort;
	costRating: number;
	preferredProvider: string;
	providers: Readonly<Record<string, string>>;
	guidelines: readonly string[];
	cautions: readonly string[];
	source?: Readonly<LogicalModelSource>;
}

export interface LogicalCompressorEntry {
	model: string;
	effort: LogicalModelEffort;
}

const LOGICAL_MODEL_NAME = /^[a-z0-9][a-z0-9._-]*$/;

/** One provider-free logical model name accepted by policy and durable history. */
export function isLogicalModelName(value: unknown): value is string {
	return typeof value === "string" && LOGICAL_MODEL_NAME.test(value);
}

function deepFreeze<T>(value: T): T {
	if (value !== null && typeof value === "object" && !Object.isFrozen(value)) {
		Object.freeze(value);
		for (const inner of Object.values(value)) deepFreeze(inner);
	}
	return value;
}

const SONNET_OPUS_CAUTION = "May exceed explicit scope or infer permission from earlier requests. Check changes against stated exclusions and approval requirements.";
const SOL_CAUTION = "When blocked, may substitute unapproved resources or perform destructive cleanup. Require permission before either action.";
const LUNA_CAUTION = "May treat supplied repair context as permission to implement despite explicit task limits. Restrict write access for record-only work and verify the changed files.";
const FLASH_CAUTION = "Do not use as a reviewer. It relies too much on passing tests and exact-size assertions. Verify source citations and distinguish proposed behavior from existing behavior.";

function providers(provider: string, model: string): Record<string, string> {
	const result = Object.create(null) as Record<string, string>;
	result[provider] = model;
	return result;
}

function fieldSource(): LogicalFieldSource {
	return {
		publisher: "DeepSWE/DataCurve",
		retrieved: "2026-09-11",
		sourceUrl: "https://deepswe.datacurve.ai/artifacts/v1.1/leaderboard-live.json",
		basis: "Project judgment informed by DeepSWE v1.1 and reviewed supporting evidence",
	};
}

function source(projectRatings = false): LogicalModelSource {
	const ratingSource: LogicalFieldSource = projectRatings
		? { publisher: "Slate project", decided: "2026-09-30", basis: "Project judgment set on 2026-09-30 without new benchmark evidence" }
		: fieldSource();
	return { capabilityRating: ratingSource, costRating: ratingSource, guidelines: fieldSource() };
}

const SHIPPED_DEFINITIONS: LogicalModelDefinition[] = [
	{
		model: "luna-6", capabilityRating: 45, effort: "max", costRating: 5,
		preferredProvider: "openai", providers: providers("openai", "gpt-6-luna"),
		guidelines: ["auxiliary tasks only, such as file location, check-result collection, or routine text management such as modifying research logs", "never primary research, implementation, design, or review", "consumer-contract work only when auxiliary"],
		cautions: [LUNA_CAUTION, "Do not use Luna to handle complex texts."], source: source(),
	},
	{
		model: "claude-sonnet-5.5", capabilityRating: 45, effort: "high", costRating: 54,
		preferredProvider: "anthropic", providers: providers("anthropic", "claude-sonnet-5-5"),
		guidelines: [], cautions: [SONNET_OPUS_CAUTION], source: source(true),
	},
	{
		model: "sol-6.1", capabilityRating: 85, effort: "high", costRating: 20,
		preferredProvider: "openai", providers: providers("openai", "gpt-6.1-sol"),
		guidelines: ["default thread choice"], cautions: [SOL_CAUTION], source: source(true),
	},
	{
		model: "gemini-3.8-flash", capabilityRating: 55, effort: "medium", costRating: 30,
		preferredProvider: "google-vertex", providers: providers("google-vertex", "gemini-3.8-flash"),
		guidelines: ["default thread choice", "generally prefer over Luna when available", "a more specific active guideline overrides this general Flash preference"],
		cautions: [FLASH_CAUTION], source: source(),
	},
	{
		model: "claude-opus-5.5", capabilityRating: 90, effort: "high", costRating: 65,
		preferredProvider: "anthropic", providers: providers("anthropic", "claude-opus-5-5"),
		guidelines: ["Reviewer for each proved DESIGN-TRIGGERING focus area, in adversarial design review and in implementation area review.", "Do not select Opus 5.5 as the default implementer. If a lower-capability model repeatedly fails at implementation, first ask Opus 5.5 to investigate and provide detailed repair instructions. Let the implementer try those instructions. Use Opus 5.5 as the implementer only if that guided attempt also fails. Treat that use as an exception. Select another suitable model for later implementation work. Existing approval requirements and repair limits still apply."], cautions: [SONNET_OPUS_CAUTION], source: source(),
	},
	{
		model: "gpt-6-astra", capabilityRating: 86, effort: "medium", costRating: 60,
		preferredProvider: "openai", providers: providers("openai", "gpt-6-astra"),
		guidelines: ["Do not select Astra as the default implementer.", "Prefer Sol 6.1 over Astra."],
		cautions: [], source: source(),
	},
];

export const SHIPPED_LOGICAL_MODELS: readonly LogicalModelDefinition[] = deepFreeze(SHIPPED_DEFINITIONS);

export const SHIPPED_COMPRESSOR_MODELS: readonly LogicalCompressorEntry[] = deepFreeze([
	{ model: "claude-sonnet-5.5", effort: "medium" },
]);

export const LOGICAL_MODEL_SOURCE_NOTES = deepFreeze({
	ratings: "Fixed project judgments. Sol 6.1 and Sonnet 5.5 ratings were set on 2026-09-30 without new benchmark evidence. Other ratings are informed by DeepSWE v1.1 by DataCurve and reviewed supporting evidence",
	guidance: "Project-authored advisory guidance informed by DeepSWE v1.1 focus analysis and approved project inference",
	source: "https://deepswe.datacurve.ai/artifacts/v1.1/leaderboard-live.json",
	retrieved: "2026-09-11",
	limits: "Ratings are not percentages, measurements, price ratios, quality guarantees, realized costs, or billing forecasts",
});
